import { z } from "zod";

export const WORKFLOW_CATALOG = [
  {
    id: "film-editorial",
    title: "Review film editorial coverage and handoff",
    summary: "Capture source and timeline context, supply an explicit film manifest, inspect coverage and review layouts, resolve revision-bound notes and turnover exceptions, then use separately guarded host tools for approved edits and exports.",
    recommendedTools: ["manage_project_context", "inspect_film_editorial_workflow", "create_editorial_plan", "preview_editorial_plan", "diff_sequence_snapshots"],
  },
  {
    id: "rough-cut",
    title: "Assemble a rough cut",
    summary: "Inspect the project, import media, create or select a sequence, assemble clips, then verify and save.",
    recommendedTools: ["get_premiere_state", "import_media", "create_sequence", "add_to_timeline", "get_sequence_structure", "save_project"],
  },
  {
    id: "project-intake",
    title: "Preview project intake",
    summary: "Inspect a bounded project against an explicit facility template and return a path-redacted intake report and non-mutating organization proposal.",
    recommendedTools: ["verify_premiere_connection", "preview_project_intake"],
  },
  {
    id: "dialogue-cleanup",
    title: "Clean up dialogue",
    summary: "Inspect audio tracks, normalize dialogue, apply conservative cleanup, and verify levels before saving.",
    recommendedTools: ["get_sequence_structure", "adjust_audio_levels", "apply_audio_effect", "save_project"],
  },
  {
    id: "caption-and-style",
    title: "Caption and style a sequence",
    summary: "Inspect the active sequence, create captions, apply styling, verify timing, and save.",
    recommendedTools: ["get_active_sequence", "create_caption_track", "get_sequence_structure", "save_project"],
  },
  {
    id: "delivery",
    title: "Prepare a delivery export",
    summary: "Validate the sequence and destination, export with an explicit preset, then report the produced artifact.",
    recommendedTools: ["get_premiere_state", "get_active_sequence", "export_sequence", "verify_delivery_file", "verify_delivery_conformance"],
  },
  {
    id: "contextual-rough-cut",
    title: "Build a context-aware rough cut",
    summary: "Capture reusable project context, retrieve only evidence relevant to the edit intent, create a revision-guarded plan, then preview before applying.",
    recommendedTools: ["manage_project_context", "search_project_context", "create_context_edit_plan", "preview_edit_plan", "apply_edit_plan"],
  },
  {
    id: "transcript-first-context",
    title: "Review a transcript-first context pack",
    summary: "Capture explicit local transcript and media evidence, compact only the passages relevant to the intent, then review stable evidence IDs and revisions before proposing an edit.",
    recommendedTools: ["manage_project_context", "create_editorial_context_pack", "create_editorial_plan", "preview_editorial_plan"],
  },
  {
    id: "transcript-rough-cut",
    title: "Plan a transcript-driven rough cut",
    summary: "Export Premiere's native transcript, select revision-locked source ranges, map them to verified 1x placements in a duplicate sequence, then execute the descending cut plan with re-query verification.",
    recommendedTools: ["get_clip_transcript_uxp", "search_clip_transcript_uxp", "preview_transcript_edit_uxp", "plan_transcript_rough_cut_uxp", "manage_sequences_uxp", "split_clip", "get_sequence_structure"],
  },
  {
    id: "metadata-review",
    title: "Review and update clip metadata",
    summary: "Inspect visible Project-panel columns first, then named project/XMP fields. Request full XML only when needed. Writes use field_name/value or complete XML, or a locked UXP field/packet transaction with readback; schema creation does not set per-item values.",
    recommendedTools: ["get_metadata", "get_xmp_metadata", "inspect_project_panel_metadata_uxp", "manage_metadata_uxp", "set_metadata", "set_xmp_metadata"],
    promptNotes: "Prefer inspect_project_panel_metadata_uxp action item_columns or manage_metadata_uxp inspect_fields / get_metadata parse_fields. CEP metadata reads default to bounded parsed fields with personal data omitted. Raw packets require explicit packet flags (include_raw for get_xmp_metadata) and include_sensitive true; source paths require include_media_path true. Request raw packets only with user authorization for their personal-data disclosure. Premiere-private project metadata is not file XMP. Do not treat premiere://project/metadata as a packet dump. Writes use field_name/value or complete XML, or a UXP update_field/update with readback; never fall back from a failed UXP write to CEP.",
  },
  {
    id: "project-organization",
    title: "Plan project organization",
    summary: "Capture project context, supply explicit editorial categories, create and preview a review-only organization plan, then use its guarded apply route with stable-ID bin operations. Direct organize_project_items_uxp use is advanced/manual only.",
    recommendedTools: ["manage_project_context", "create_editorial_plan", "preview_editorial_plan", "apply_editorial_organization_plan"],
  },
  {
    id: "ai-assisted-stringout",
    title: "Plan a reviewed stringout",
    summary: "Retrieve relevant local evidence, produce a review-only stringout plan, resolve selected project items, then create and verify a new sequence.",
    recommendedTools: ["manage_project_context", "create_editorial_plan", "preview_editorial_plan", "manage_sequences_uxp", "edit_timeline_uxp"],
  },
  {
    id: "caption-artifact-review",
    title: "Review a caption artifact",
    summary: "Use existing transcript evidence to review a supplied caption artifact, import it deliberately, create a caption track, and verify playback before delivery.",
    recommendedTools: ["manage_project_context", "create_editorial_plan", "preview_editorial_plan", "import_media", "create_caption_track", "get_sequence_structure"],
  },
  {
    id: "reaction-shorts",
    title: "Caption and deliver reaction Shorts",
    summary: "Plan stacked speaker-colored captions without guessing unknown speakers, place a mid-video subscribe overlay, export into a series-named folder, then verify review frames before delivery.",
    recommendedTools: ["plan_reaction_captions", "plan_short_subscribe_cta", "plan_short_export_folder", "import_mogrt", "export_sequence_review_frames", "export_sequence"],
  },
  {
    id: "platform-cutdown",
    title: "Plan platform cutdowns",
    summary: "Capture source-sequence context, propose bounded platform dimensions, review derivative sequence routes, then create and verify each cutdown deliberately.",
    recommendedTools: ["manage_project_context", "create_editorial_plan", "preview_editorial_plan", "manage_sequences_uxp", "auto_reframe_sequence", "get_sequence_structure", "export_sequence"],
  },
  {
    id: "dialogue-first-cut",
    title: "Review a dialogue-first cut",
    summary: "Analyze supplied transcript evidence locally, review deterministic candidates, lock source revisions, then create and structurally verify a new ordinary sequence.",
    recommendedTools: ["get_clip_transcript_uxp", "analyze_dialogue_edit_candidates", "preview_derived_dialogue_sequence_uxp", "apply_derived_dialogue_sequence_uxp", "get_sequence_structure"],
  },
  {
    id: "podcast-first-cut",
    title: "Review a podcast first cut",
    summary: "Review speaker and synchronization assignments, bind every camera segment to a transcript revision and master-audio range, then create a new ordinary sequence without changing sources.",
    recommendedTools: ["get_clip_transcript_uxp", "analyze_dialogue_edit_candidates", "preview_derived_dialogue_sequence_uxp", "apply_derived_dialogue_sequence_uxp", "inspect_sequence_review_report"],
  },
  {
    id: "watched-media-intake",
    title: "Review watched media intake",
    summary: "Start a session-scoped local watcher, inspect its path-redacted candidate set, then deliberately import only approved files.",
    recommendedTools: ["manage_media_watch", "preview_watched_media_import", "import_project_media_uxp", "get_project_info"],
  },
  {
    id: "recipe-driven-edit",
    title: "Preview a workflow recipe",
    summary: "Select a built-in or workspace-local declarative recipe, review its allowlisted tool manifest, then execute each step through the normal guarded tools.",
    recommendedTools: ["search_workflow_recipes", "preview_workflow_recipe", "get_premiere_state"],
  },
  {
    id: "dialogue-candidate-review",
    title: "Review dialogue cuts with padding",
    summary: "Inspect captured dialogue candidates with words in context, explicitly keep or reject cuts, and review unioned source-time removal before a separate guarded derivative preview.",
    recommendedTools: ["review_dialogue_candidates", "preview_derived_dialogue_sequence_uxp"],
  },
  {
    id: "quote-paper-edit",
    title: "Review a quote paper edit",
    summary: "Order explicitly approved source quotes and return running timings plus an inline spreadsheet-safe CSV before any multi-source host assembly.",
    recommendedTools: ["review_quote_paper_edit"],
  },
  {
    id: "batch-copy-review",
    title: "Review batch text changes",
    summary: "Compare inspected MOGRT text or supplied caption-artifact copy with literal or proposed changes, preserve original text, and approve exact fields before fresh host readback.",
    recommendedTools: ["review_text_changes", "get_mogrt_component"],
  },
  {
    id: "sync-evidence-review",
    title: "Review camera and recorder matches",
    summary: "Compare supplied independent offset estimates, resolve conflicts, and explicitly approve camera-recorder matches before a separate host sequence preview.",
    recommendedTools: ["review_sync_evidence", "preview_derived_dialogue_sequence_uxp"],
  },
  {
    id: "broll-placement-review",
    title: "Review owned-footage B-roll picks",
    summary: "Review caller-proposed footage against dialogue, reasons and alternatives, approve non-overlapping video-only placements, then inspect occupancy in a fresh edit-plan preview.",
    recommendedTools: ["review_broll_placements", "preview_edit_plan"],
  },
] as const;

export const WORKFLOW_RESOURCE = JSON.stringify(
  {
    version: 1,
    guidance: [
      "Inspect current state before mutating the project.",
      "Re-query clip identifiers after timeline edits.",
      "Prefer visible Project-panel column JSON over dumping full XMP or project-metadata packets.",
      "Ask for confirmation before destructive edits or final exports when intent is ambiguous.",
      "Verify the resulting sequence and save only after successful edits.",
    ],
    workflows: WORKFLOW_CATALOG,
  },
  null,
  2,
);

const commonArgs = {
  goal: z.string().describe("What the finished edit should accomplish"),
  constraints: z.string().optional().describe("Timing, style, media, or delivery constraints"),
};

export const WORKFLOW_PROMPTS = WORKFLOW_CATALOG.map((workflow) => ({
  name: `premiere-${workflow.id}`,
  title: workflow.title,
  description: workflow.summary,
  argsSchema: commonArgs,
  render: ({ goal, constraints }: { goal: string; constraints?: string }) => ({
    description: `${workflow.title}: ${goal}`,
    messages: [
      {
        role: "user" as const,
        content: {
          type: "text" as const,
          text: [
            `Use the ${workflow.title.toLowerCase()} workflow to accomplish: ${goal}`,
            constraints ? `Constraints: ${constraints}` : undefined,
            `Begin with project inspection. Prefer these tools when applicable: ${workflow.recommendedTools.join(", ")}.`,
            "promptNotes" in workflow ? workflow.promptNotes : undefined,
            "Before each mutation, validate the active project/sequence and relevant identifiers. After editing, inspect the result and clearly report completed, skipped, and failed steps.",
          ].filter(Boolean).join("\n"),
        },
      },
    ],
  }),
}));
