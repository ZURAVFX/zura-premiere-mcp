import { buildToolScript, escapeForExtendScript } from "../bridge/script-builder.js";
import { sendCommand, BridgeOptions } from "../bridge/file-bridge.js";
import { execFile } from "node:child_process";
import { existsSync, statSync } from "node:fs";
import { basename, dirname, extname, resolve } from "node:path";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

/** Cap on a single ffmpeg analysis pass. Decode-only, so this is generous. */
const FFMPEG_TIMEOUT_MS = 300_000;

// Premiere stores Volume > Level as a normalized value, not a linear gain.
// Its maximum value (1) represents +15 dB, so 0 dB is 10^(-15/20).
export const PREMIERE_MAX_LEVEL_DB = 15;

export function dbToPremiereLevel(db: number): number {
  return Math.pow(10, (db - PREMIERE_MAX_LEVEL_DB) / 20);
}

/** ES3 key storage readback shared by audio automation tools. */
export const AUDIO_KEYFRAME_READBACK = `
  function audioTick(value) {
    if (typeof value !== "number" && (typeof value !== "string" || !/^[0-9]+$/.test(value))) throw new Error("Unreadable key clock");
    var tick = Number(value);
    if (!isFinite(tick) || tick < 0 || tick > 9007199254740991 || Math.floor(tick) !== tick) throw new Error("Unsafe key clock");
    return tick;
  }
  function audioKeys(prop) {
    var keys = prop.getKeys();
    if (__isEmptyKeyList(prop, keys)) return [];
    if (!keys || typeof keys.length !== "number" || !isFinite(keys.length) || keys.length < 0 || Math.floor(keys.length) !== keys.length) throw new Error("Unreadable key storage");
    var ticks = [];
    for (var k = 0; k < keys.length; k++) ticks.push(audioTick(keys[k].ticks));
    return ticks;
  }
  function audioVerify(prop, time, expected) {
    var ticks = audioKeys(prop);
    var target = audioTick(time.ticks);
    var found = false;
    for (var k = 0; k < ticks.length; k++) if (ticks[k] === target) found = true;
    var actual = prop.getValueAtTime(time);
    if (!found || typeof actual !== "number" || !isFinite(actual) || Math.abs(actual - expected) > expected * 0.000001) throw new Error("Stored audio key or Level differed");
    return actual;
  }
`;

export interface SilenceInterval {
  start: number;
  end: number;
  duration: number;
}

export interface TimelineSilenceCandidate {
  sourceStartSeconds: number;
  sourceEndSeconds: number;
  durationSeconds: number;
  timelineStartSeconds: number;
  timelineEndSeconds: number;
}

export interface SilenceTimelineMapping {
  candidates: TimelineSilenceCandidate[];
  totalCandidateCount: number;
  truncated: boolean;
}

export interface LoudnessMeasurement {
  integratedLufs: number | null;
  loudnessRangeLu: number | null;
  truePeakDbfs: number | null;
}

export interface BeatMeasurement {
  bpm: number;
  confidence: number;
  beatTimesSeconds: number[];
  durationSeconds: number;
}

/** The decoded audio holds no usable beat (too short, or no repeating pulse). */
export class NoBeatError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "NoBeatError";
  }
}

/** Estimate a steady beat grid from signed 16-bit mono samples at a low analysis rate. */
export function analyzeBeatPcm(samples: Int16Array, sampleRate: number): BeatMeasurement {
  if (!Number.isFinite(sampleRate) || sampleRate < 20 || samples.length < sampleRate * 2) {
    throw new NoBeatError("Beat analysis requires at least two seconds of finite-rate audio");
  }
  // A 100 Hz onset envelope: at 20 Hz the period could only take 50 ms steps,
  // so 73 BPM (0.822 s) snapped to 75 BPM (0.8 s) and the grid drifted.
  const hop = Math.max(1, Math.round(sampleRate / 100));
  const envelope: number[] = [];
  for (let offset = 0; offset + hop <= samples.length; offset += hop) {
    let energy = 0;
    for (let index = offset; index < offset + hop; index++) energy += Math.abs(samples[index]);
    envelope.push(energy / hop);
  }
  // Half-second moving baseline either side, whatever the envelope rate.
  const baselineHalfWidth = Math.max(1, Math.round((sampleRate / hop) * 0.5));
  const onset = envelope.map((value, index) => {
    let baseline = 0;
    let count = 0;
    for (let at = Math.max(0, index - baselineHalfWidth); at <= Math.min(envelope.length - 1, index + baselineHalfWidth); at++) {
      baseline += envelope[at]; count++;
    }
    return Math.max(0, value - baseline / count);
  });
  const envelopeRate = sampleRate / hop;
  const minLag = Math.max(1, Math.floor(envelopeRate * 60 / 200));
  const maxLag = Math.min(onset.length - 1, Math.ceil(envelopeRate * 60 / 60));
  let bestLag = minLag;
  let bestScore = -1;
  const lagScores = new Map<number, number>();
  for (let lag = minLag; lag <= maxLag; lag++) {
    let score = 0;
    for (let index = 0; index + lag < onset.length; index++) score += onset[index] * onset[index + lag];
    score /= Math.max(1, onset.length - lag);
    lagScores.set(lag, score);
    if (score > bestScore) { bestScore = score; bestLag = lag; }
  }
  // Autocorrelation often gives equal strength to half time. Prefer the
  // octave-up pulse only when its exact divisor retains most of the evidence.
  while (Math.round(bestLag / 2) >= minLag) {
    const halfLag = Math.round(bestLag / 2);
    const halfScore = lagScores.get(halfLag) ?? -1;
    if (halfScore < bestScore * 0.8) break;
    bestLag = halfLag;
    bestScore = halfScore;
  }
  let selfScore = 0;
  for (const value of onset) selfScore += value * value;
  selfScore /= onset.length;
  const confidence = Math.max(0, Math.min(1, selfScore > 0 ? bestScore / selfScore : 0));
  if (!Number.isFinite(confidence) || confidence < 0.05) {
    throw new NoBeatError("No repeating beat evidence was detected in the decoded media");
  }
  // Refine the whole-sample lag to a fractional period with a comb over the
  // full file, so the beat grid does not drift on long material.
  const onsetAt = (position: number) => {
    const whole = Math.floor(position);
    if (whole < 0 || whole + 1 >= onset.length) return 0;
    const fraction = position - whole;
    return onset[whole] * (1 - fraction) + onset[whole + 1] * fraction;
  };
  const comb = (period: number) => {
    let bestScore = -1;
    let bestPhase = 0;
    for (let phase = 0; phase < period; phase += 0.5) {
      let score = 0;
      for (let position = phase; position < onset.length - 1; position += period) score += onsetAt(position);
      if (score > bestScore) { bestScore = score; bestPhase = phase; }
    }
    return { score: bestScore, phase: bestPhase };
  };
  const candidates: Array<{ period: number; score: number }> = [];
  for (let step = -100; step <= 100; step++) {
    const candidate = bestLag + step / 100;
    if (candidate <= 0 || candidate < minLag - 1) continue;
    candidates.push({ period: candidate, score: comb(candidate).score });
  }
  // Wide onsets give a plateau of equally scoring periods; take its centre.
  const topScore = Math.max(...candidates.map((entry) => entry.score));
  const tied = candidates.filter((entry) => entry.score >= topScore * 0.999).map((entry) => entry.period);
  const period = (Math.min(...tied) + Math.max(...tied)) / 2;
  const best = comb(period);
  const bpm = 60 * envelopeRate / period;
  const beatTimesSeconds: number[] = [];
  for (let position = best.phase; position < onset.length; position += period) {
    beatTimesSeconds.push(Number((position / envelopeRate).toFixed(3)));
  }
  return {
    bpm: Number(bpm.toFixed(1)),
    confidence: Number(confidence.toFixed(2)),
    beatTimesSeconds,
    durationSeconds: Number((samples.length / sampleRate).toFixed(3)),
  };
}

function finiteMetric(value: string | undefined): number | null {
  if (!value || value.toLowerCase().includes("inf")) return null;
  const parsed = Number.parseFloat(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/** Parse the final summary emitted by ffmpeg's EBU R128 filter. */
export function parseEbur128Summary(stderr: string): LoudnessMeasurement {
  const summaries = [...stderr.matchAll(/Summary:\s*([\s\S]*?)(?=(?:\r?\n\S)|$)/g)];
  const summary = summaries.at(-1)?.[1] ?? stderr;
  return {
    integratedLufs: finiteMetric(summary.match(/Integrated loudness:[\s\S]*?\bI:\s*(-?(?:inf|\d+(?:\.\d+)?))\s+LUFS/i)?.[1]),
    loudnessRangeLu: finiteMetric(summary.match(/Loudness range:[\s\S]*?\bLRA:\s*(-?(?:inf|\d+(?:\.\d+)?))\s+LU/i)?.[1]),
    truePeakDbfs: finiteMetric(summary.match(/True peak:[\s\S]*?\bPeak:\s*(-?(?:inf|\d+(?:\.\d+)?))\s+dBFS/i)?.[1]),
  };
}

export interface LoudnormStats {
  input_i: string; input_tp: string; input_lra: string; input_thresh: string; target_offset: string;
  normalization_type?: string;
}

/** The JSON block loudnorm prints to stderr with print_format=json. */
export function parseLoudnormJson(stderr: string): LoudnormStats {
  const start = stderr.lastIndexOf("{");
  const end = stderr.lastIndexOf("}");
  if (start < 0 || end < start) throw new Error("loudnorm printed no measurement");
  const stats = JSON.parse(stderr.slice(start, end + 1)) as LoudnormStats;
  for (const key of ["input_i", "input_tp", "input_lra", "input_thresh", "target_offset"] as const) {
    if (!Number.isFinite(Number(stats[key]))) throw new Error(`loudnorm measurement is missing ${key} (silent input?)`);
  }
  return stats;
}

async function probeAudioStream(path: string): Promise<{ sampleRate: number | null; bitRate: number | null } | null> {
  try {
    const { stdout } = await execFileAsync("ffprobe", ["-v", "error", "-select_streams", "a:0", "-show_entries", "stream=sample_rate,bit_rate", "-of", "json", path], { timeout: 15000 });
    const stream = JSON.parse(stdout).streams?.[0];
    if (!stream) return null;
    const rate = Number(stream.sample_rate);
    const bits = Number(stream.bit_rate);
    return { sampleRate: Number.isFinite(rate) && rate > 0 ? rate : null, bitRate: Number.isFinite(bits) && bits > 0 ? bits : null };
  } catch {
    return { sampleRate: null, bitRate: null };
  }
}

/**
 * Parse ffmpeg's silencedetect output.
 *
 * silencedetect writes to stderr as `silence_start: 12.5` and
 * `silence_end: 18.25 | silence_duration: 5.75`. A run of silence that reaches
 * the end of the file has a start with no matching end, so it is closed at the
 * media duration.
 */
export function parseSilenceDetectOutput(
  stderr: string,
  totalDuration: number | null,
): SilenceInterval[] {
  const intervals: SilenceInterval[] = [];
  let pendingStart: number | null = null;

  for (const line of stderr.split(/\r?\n/)) {
    const start = line.match(/silence_start:\s*(-?[\d.]+)/);
    if (start) {
      pendingStart = Math.max(0, Number.parseFloat(start[1]));
      continue;
    }
    const end = line.match(/silence_end:\s*(-?[\d.]+)/);
    if (end && pendingStart !== null) {
      const endSeconds = Number.parseFloat(end[1]);
      intervals.push({
        start: pendingStart,
        end: endSeconds,
        duration: Number((endSeconds - pendingStart).toFixed(3)),
      });
      pendingStart = null;
    }
  }

  // Silence running to EOF never gets a silence_end line.
  if (pendingStart !== null && totalDuration !== null && totalDuration > pendingStart) {
    intervals.push({
      start: pendingStart,
      end: totalDuration,
      duration: Number((totalDuration - pendingStart).toFixed(3)),
    });
  }

  return intervals;
}

/** Pull the media duration out of ffmpeg's `Duration: 00:00:20.00` banner line. */
export function parseDurationSeconds(stderr: string): number | null {
  const match = stderr.match(/Duration:\s*(\d+):(\d{2}):(\d{2}(?:\.\d+)?)/);
  if (!match) return null;
  return (
    Number.parseInt(match[1], 10) * 3600 +
    Number.parseInt(match[2], 10) * 60 +
    Number.parseFloat(match[3])
  );
}

/**
 * Invert the silence ranges into the segments worth keeping. This is what an
 * actual "strip the dead air" edit needs, and deriving it here avoids every
 * caller reimplementing the same interval arithmetic.
 */
export function invertToSegments(
  silences: SilenceInterval[],
  totalDuration: number | null,
): SilenceInterval[] {
  if (totalDuration === null) return [];
  const segments: SilenceInterval[] = [];
  let cursor = 0;

  for (const silence of silences) {
    if (silence.start > cursor) {
      segments.push({
        start: cursor,
        end: silence.start,
        duration: Number((silence.start - cursor).toFixed(3)),
      });
    }
    cursor = Math.max(cursor, silence.end);
  }

  if (cursor < totalDuration) {
    segments.push({
      start: cursor,
      end: totalDuration,
      duration: Number((totalDuration - cursor).toFixed(3)),
    });
  }

  return segments;
}

/**
 * Map source-media silence ranges to a known 1x timeline placement.
 *
 * The plan deliberately has no speed, reverse, remap, multicam, or nested-sequence
 * mode: those mappings need host evidence and should not be guessed from source
 * timestamps. Ranges are clipped to the visible source span before they are mapped.
 */
export function mapSilenceIntervalsToTimeline(
  silences: SilenceInterval[],
  options: {
    sourceInSeconds: number;
    sourceOutSeconds: number;
    timelineStartSeconds: number;
    maxCandidates: number;
  },
): SilenceTimelineMapping {
  const candidates: TimelineSilenceCandidate[] = [];
  let totalCandidateCount = 0;

  for (const silence of silences) {
    const sourceStartSeconds = Math.max(silence.start, options.sourceInSeconds);
    const sourceEndSeconds = Math.min(silence.end, options.sourceOutSeconds);
    if (sourceEndSeconds <= sourceStartSeconds) continue;

    totalCandidateCount++;
    if (candidates.length >= options.maxCandidates) continue;

    const timelineStartSeconds = options.timelineStartSeconds + sourceStartSeconds - options.sourceInSeconds;
    const timelineEndSeconds = options.timelineStartSeconds + sourceEndSeconds - options.sourceInSeconds;
    candidates.push({
      sourceStartSeconds: Number(sourceStartSeconds.toFixed(3)),
      sourceEndSeconds: Number(sourceEndSeconds.toFixed(3)),
      durationSeconds: Number((sourceEndSeconds - sourceStartSeconds).toFixed(3)),
      timelineStartSeconds: Number(timelineStartSeconds.toFixed(3)),
      timelineEndSeconds: Number(timelineEndSeconds.toFixed(3)),
    });
  }

  return {
    candidates,
    totalCandidateCount,
    truncated: totalCandidateCount > candidates.length,
  };
}

export interface SilenceAnalysis {
  noiseThresholdDb: number;
  minDurationSeconds: number;
  totalDurationSeconds: number | null;
  silenceIntervals: SilenceInterval[];
  segments: SilenceInterval[];
  silentSeconds: number;
}

/** Run the local, decode-only FFmpeg silence analysis shared by review workflows. */
export async function analyzeSilenceFile(
  mediaPath: string,
  noiseDb: number,
  minDuration: number,
): Promise<{ success: true; data: SilenceAnalysis } | { success: false; error: string }> {
  if (!existsSync(mediaPath)) {
    return { success: false, error: `Media file not found on disk: ${mediaPath}` };
  }

  try {
    await execFileAsync("ffmpeg", ["-version"], { timeout: 10_000 });
  } catch {
    return {
      success: false,
      error:
        "ffmpeg was not found on PATH. Silence analysis needs it because Premiere's scripting API exposes no audio-level data. Install ffmpeg (brew install ffmpeg, or winget install Gyan.FFmpeg) and retry.",
    };
  }

  const ffmpegArgs = [
    "-nostdin",
    "-hide_banner",
    "-i",
    mediaPath,
    "-af",
    `silencedetect=noise=${noiseDb}dB:d=${minDuration}`,
    "-f",
    "null",
    "-",
  ];

  let stderr: string;
  try {
    // silencedetect reports on stderr, and `-f null -` exits 0 on success.
    const result = await execFileAsync("ffmpeg", ffmpegArgs, {
      timeout: FFMPEG_TIMEOUT_MS,
      maxBuffer: 32 * 1024 * 1024,
    });
    stderr = result.stderr;
  } catch (error) {
    const failure = error as { killed?: boolean; stderr?: string; message?: string };
    if (failure.killed) {
      return {
        success: false,
        error: `ffmpeg timed out after ${FFMPEG_TIMEOUT_MS / 1000}s analysing ${mediaPath}.`,
      };
    }
    const detail = (failure.stderr ?? failure.message ?? "")
      .split(/\r?\n/)
      .filter((line) => line.trim())
      .slice(-3)
      .join(" ");
    return {
      success: false,
      error: `ffmpeg could not analyse ${mediaPath}: ${detail || "unknown error"}`,
    };
  }

  const totalDurationSeconds = parseDurationSeconds(stderr);
  const silenceIntervals = parseSilenceDetectOutput(stderr, totalDurationSeconds);
  const segments = invertToSegments(silenceIntervals, totalDurationSeconds);
  const silentSeconds = silenceIntervals.reduce((sum, interval) => sum + interval.duration, 0);

  return {
    success: true,
    data: {
      noiseThresholdDb: noiseDb,
      minDurationSeconds: minDuration,
      totalDurationSeconds,
      silenceIntervals,
      segments,
      silentSeconds: Number(silentSeconds.toFixed(3)),
    },
  };
}

export function getAudioTools(bridgeOptions: BridgeOptions) {
  return {
    adjust_audio_levels: {
      description: "Adjust a clip's Volume > Level in dB. Does not read or change Essential Sound Amplify automation.",
      parameters: {
        type: "object" as const,
        properties: {
          node_id: {
            type: "string",
            description: "Node ID of the audio or video clip",
          },
          level_db: {
            type: "number",
            description: "Audio level in dB (0 = unity, negative = quieter, positive = louder)",
          },
      },
      required: ["node_id", "level_db"],
      },
      handler: async (args: { node_id: string; level_db: number }) => {
        if (!Number.isFinite(args.level_db) || args.level_db > PREMIERE_MAX_LEVEL_DB) {
          return {
            success: false,
            error: `level_db must be a finite value at or below +${PREMIERE_MAX_LEVEL_DB} dB`,
          };
        }
        const normalizedLevel = dbToPremiereLevel(args.level_db);
        if (normalizedLevel <= 0) return { success: false, error: "level_db is too small to represent as a nonzero normalized level" };
        const script = buildToolScript(`
          var result = __findClip("${escapeForExtendScript(args.node_id)}");
          if (!result) return __error("Clip not found");
          
          var clip = result.clip;
          // Find the Volume component
          for (var i = 0; i < clip.components.numItems; i++) {
            var comp = clip.components[i];
            var __m = String(comp.matchName || "");
            if (comp.displayName === "Volume" || comp.displayName === "Volumen" || __m.indexOf("Internal Volume") === 0 || __m === "audioVolume") {
              for (var p = 0; p < comp.properties.numItems; p++) {
                var __pn = String(comp.properties[p].displayName);
                  if (__pn === "Level" || __pn === "Nivel") {
                  var levelProp = comp.properties[p];
                  var requestedLevel = ${normalizedLevel};
                  var beforeLevel;
                  try { beforeLevel = levelProp.getValue(); } catch (e) { return __error("Cannot read audio level; nothing was changed."); }
                  if (typeof beforeLevel !== "number" || !isFinite(beforeLevel)) return __error("Cannot read audio level; nothing was changed.");
                  var writeResult = null;
                  var writeError = "";
                  try { writeResult = levelProp.setValue(requestedLevel, true); } catch (e) { writeError = String(e); }
                  var appliedLevel = NaN;
                  try { var observedLevel = levelProp.getValue(); if (typeof observedLevel === "number") appliedLevel = observedLevel; } catch (e) {}
                  var data = { verified: false, outcome: "committed_unverified", requestedLevel: requestedLevel, normalizedLevel: isFinite(appliedLevel) ? appliedLevel : null };
                  if (isFinite(appliedLevel) && appliedLevel !== beforeLevel) data.timelineChanged = true;
                  var appliedDb = appliedLevel > 0 ? (20 * (Math.log(appliedLevel) / Math.LN10) + ${PREMIERE_MAX_LEVEL_DB}) : null;
                  if (writeError || !isFinite(appliedLevel) || Math.abs(appliedLevel - requestedLevel) > 0.0001 || appliedDb === null || Math.abs(appliedDb - ${args.level_db}) > 0.01) {
                    return __jsonStringify({ success: false, error: "Premiere did not apply the requested audio level or could not confirm it. Inspect Volume > Level before retrying. " + writeError, data: data });
                  }
                  return __result({ adjusted: true, verified: true, outcome: "verified", clipName: clip.name, levelDb: ${args.level_db}, normalizedLevel: appliedLevel, writeResult: writeResult });
                }
              }
            }
          }
          
          return __error("Could not find Volume/Level property on clip");
        `);
        return sendCommand(script, bridgeOptions);
      },
    },

    add_audio_keyframes: {
      description: "Add audio level keyframes to create fades or level changes",
      parameters: {
        type: "object" as const,
        properties: {
          node_id: {
            type: "string",
            description: "Node ID of the clip",
          },
          keyframes: {
            type: "array",
            minItems: 1,
            items: {
              type: "object",
              properties: {
                time_seconds: { type: "number", minimum: 0, description: "Time in seconds relative to clip start" },
                level_db: { type: "number", maximum: 15, description: "Audio level in dB (maximum +15 dB)" },
              },
              required: ["time_seconds", "level_db"],
            },
            description: "Array of keyframe objects with time_seconds and level_db",
          },
        },
        required: ["node_id", "keyframes"],
      },
      handler: async (args: { node_id: string; keyframes: Array<{ time_seconds: number; level_db: number }> }) => {
        if (!Array.isArray(args.keyframes) || args.keyframes.length === 0 || args.keyframes.some((kf) =>
          !kf || !Number.isFinite(kf.time_seconds) || kf.time_seconds < 0 || !Number.isFinite(kf.level_db) || kf.level_db > PREMIERE_MAX_LEVEL_DB || !Number.isFinite(dbToPremiereLevel(kf.level_db)) || dbToPremiereLevel(kf.level_db) <= 0 || !Number.isSafeInteger(Math.round(kf.time_seconds * 254016000000)))) {
          return { success: false, error: "keyframes must contain finite non-negative times and level_db must be at most +15 dB (Premiere's maximum clip level)" };
        }
        const offsets = args.keyframes.map((kf) => Math.round(kf.time_seconds * 254016000000));
        if (new Set(offsets).size !== offsets.length) return { success: false, error: "keyframe times must be distinct in Premiere ticks" };
        const plannedKeys = args.keyframes.map((kf, index) => `{ offset: ${offsets[index]}, amplitude: ${dbToPremiereLevel(kf.level_db)} }`).join(",");

        const script = buildToolScript(`
          var result = __findClip("${escapeForExtendScript(args.node_id)}");
          if (!result) return __error("Clip not found");

          var clip = result.clip;
          var levelProp = null;

          for (var i = 0; i < clip.components.numItems; i++) {
            var comp = clip.components[i];
            var __m = String(comp.matchName || "");
            if (comp.displayName === "Volume" || comp.displayName === "Volumen" || __m.indexOf("Internal Volume") === 0 || __m === "audioVolume") {
              for (var p = 0; p < comp.properties.numItems; p++) {
                var __pn = String(comp.properties[p].displayName);
                  if (__pn === "Level" || __pn === "Nivel") {
                  levelProp = comp.properties[p];
                  break;
                }
              }
            }
          }

          if (!levelProp) return __error("Could not find audio Level property");
          var base = __clipKeyframeBase(clip);
          if (!base.ok) return __error(base.error);
          if (${Math.max(...args.keyframes.map((kf) => kf.time_seconds))} > base.durationSeconds) return __error("Keyframe time exceeds clip duration; nothing was changed.");

          ${AUDIO_KEYFRAME_READBACK}
          var keys = [${plannedKeys}];
          try {
            audioKeys(levelProp);
            var inTicks = audioTick(clip.inPoint.ticks);
            var durationTicks = audioTick(clip.end.ticks) - audioTick(clip.start.ticks);
            for (var k = 0; k < keys.length; k++) {
              if (keys[k].offset > durationTicks) throw new Error("Key exceeds clip duration");
              keys[k].time = new Time();
              keys[k].time.ticks = String(audioTick(inTicks + keys[k].offset));
            }
          } catch (preflightError) { return __error("Audio keyframe storage or clock could not be read; nothing was changed. " + String(preflightError)); }
          try {
            levelProp.setTimeVarying(true);
            for (var k = 0; k < keys.length; k++) {
              var key = keys[k];
              try { levelProp.addKey(key.time); } catch (addError) {}
              try { levelProp.setValueAtKey(key.time, key.amplitude, 1); }
              catch (writeError) { levelProp.setValueAtTime(key.time, key.amplitude, 1); }
            }
            for (var k = 0; k < keys.length; k++) audioVerify(levelProp, keys[k].time, keys[k].amplitude);
          } catch (verificationError) {
            return __jsonStringify({ success: false, error: "Audio keyframes could not be verified; inspect the clip before retrying. " + String(verificationError), data: { outcome: "committed_unverified", verified: false, mutationAttempted: true, timelineChanged: null } });
          }
          return __result({ keyframesAdded: ${args.keyframes.length}, verified: true, renderVerified: false, outcome: "verified", clipName: clip.name });
        `);
        return sendCommand(script, bridgeOptions);
      },
    },

    mute_track: {
      description: "Mute or unmute an audio track",
      parameters: {
        type: "object" as const,
        properties: {
          track_index: {
            type: "number",
            description: "Audio track index (0-based)",
          },
          muted: {
            type: "boolean",
            description: "True to mute, false to unmute",
          },
        },
        required: ["track_index", "muted"],
      },
      handler: async (args: { track_index: number; muted: boolean }) => {
        if (!Number.isInteger(args.track_index) || args.track_index < 0 || typeof args.muted !== "boolean") {
          return { success: false, error: "track_index must be a non-negative integer and muted must be a boolean" };
        }
        const script = buildToolScript(`
          var seq = app.project.activeSequence;
          if (!seq) return __error("No active sequence");

          if (${args.track_index} >= seq.audioTracks.numTracks) return __error("Track index out of range");

          var track = seq.audioTracks[${args.track_index}];
          function readMute() {
            var state = track.isMuted();
            if (state !== true && state !== false && state !== 0 && state !== 1) throw new Error("Unknown mute state");
            return state === true || state === 1;
          }
          var before;
          try { before = readMute(); } catch (e) { return __error("Cannot read track mute state; nothing was changed."); }
          var writeError = "";
          try { track.setMute(${args.muted ? 1 : 0}); } catch (e) { writeError = String(e); }
          var after = null;
          try { after = readMute(); } catch (e) {}
          var data = { trackIndex: ${args.track_index}, muted: after, trackName: track.name, verified: false, outcome: "committed_unverified" };
          if (after !== null && after !== before) data.timelineChanged = true;
          if (after !== ${args.muted} || writeError) {
            return __jsonStringify({ success: false, error: "Track mute could not be verified. Inspect the track before retrying. " + writeError, data: data });
          }
          data.verified = true;
          data.outcome = "verified";
          return __result(data);
        `);
        return sendCommand(script, bridgeOptions);
      },
    },

    detect_silence: {
      description:
        "Find silent ranges in a media file and return both the silences and the complementary segments worth keeping. Analysis only — nothing in the project or on the timeline is modified. Requires ffmpeg on PATH: Premiere's scripting API exposes no audio-level or waveform data, so silence cannot be measured through the bridge.",
      parameters: {
        type: "object" as const,
        properties: {
          media_path: {
            type: "string",
            description:
              "Absolute path to the media file to analyse. Provide this or project_item_id.",
          },
          project_item_id: {
            type: "string",
            description:
              "Node ID or name of a project item whose media path is resolved through Premiere. Provide this or media_path.",
          },
          noise_threshold_db: {
            type: "number",
            description:
              "Level at or below which audio counts as silence, in dBFS. Closer to 0 is more aggressive (default: -30).",
          },
          min_duration_seconds: {
            type: "number",
            description:
              "Shortest run of silence to report, in seconds (default: 1.5).",
          },
        },
      },
      handler: async (args: {
        media_path?: string;
        project_item_id?: string;
        noise_threshold_db?: number;
        min_duration_seconds?: number;
      }) => {
        const noiseDb = args.noise_threshold_db ?? -30;
        const minDuration = args.min_duration_seconds ?? 1.5;

        if (!args.media_path && !args.project_item_id) {
          return {
            success: false,
            error: "detect_silence requires media_path or project_item_id.",
          };
        }
        // These are interpolated into the ffmpeg filter string, so they must be
        // finite numbers and nothing else.
        if (!Number.isFinite(noiseDb) || noiseDb > 0) {
          return {
            success: false,
            error: `noise_threshold_db must be a finite dBFS value at or below 0 (got ${noiseDb}).`,
          };
        }
        if (!Number.isFinite(minDuration) || minDuration <= 0) {
          return {
            success: false,
            error: `min_duration_seconds must be a finite value greater than 0 (got ${minDuration}).`,
          };
        }

        let mediaPath = args.media_path;
        let itemName: string | undefined;

        if (!mediaPath) {
          const escaped = escapeForExtendScript(args.project_item_id as string);
          const lookup = await sendCommand(
            buildToolScript(`
              var item = __findProjectItem("${escaped}");
              if (!item) return __error("Project item not found: ${escaped}");
              var path = "";
              try { path = item.getMediaPath(); } catch(e) {}
              if (!path) return __error("Project item '${escaped}' has no media path — it may be a sequence, a bin, or a synthetic item such as a title or colour matte.");
              return __result({ mediaPath: path, name: item.name });
            `),
            bridgeOptions,
          );
          if (!lookup.success) return lookup;
          const data = lookup.data as { mediaPath: string; name?: string };
          mediaPath = data.mediaPath;
          itemName = data.name;
        }

        if (!existsSync(mediaPath)) {
          return {
            success: false,
            error: `Media file not found on disk: ${mediaPath}${
              itemName ? ` (resolved from project item '${itemName}')` : ""
            }. It may be offline or relinked.`,
          };
        }

        const analysis = await analyzeSilenceFile(mediaPath, noiseDb, minDuration);
        if (!analysis.success) return analysis;

        return {
          success: true,
          data: {
            mediaPath,
            projectItemName: itemName,
            ...analysis.data,
            note: "Detection only — no clip was cut or removed. Times are relative to the start of the media file, not the timeline.",
          },
        };
      },
    },

    plan_silence_review_markers: {
      description:
        "Create a bounded, non-mutating review plan that maps FFmpeg-detected source-media silences onto one known 1x timeline placement. It clips candidates to the supplied source in/out span, redacts the source path, and never adds markers, cuts clips, or changes Premiere.",
      parameters: {
        type: "object" as const,
        additionalProperties: false,
        properties: {
          media_path: {
            type: "string",
            description: "Absolute path to the local source media file to analyse.",
          },
          timeline_start_seconds: {
            type: "number",
            description: "Timeline time where this 1x source placement begins.",
          },
          source_in_seconds: {
            type: "number",
            description: "Source-media in point used by the placement (default: 0).",
          },
          source_out_seconds: {
            type: "number",
            description: "Exclusive source-media out point used by the placement. Defaults to the detected media duration when available.",
          },
          noise_threshold_db: {
            type: "number",
            description: "Level at or below which audio counts as silence, in dBFS (default: -30).",
          },
          min_duration_seconds: {
            type: "number",
            description: "Shortest run of silence to consider (default: 1.5).",
          },
          max_candidates: {
            type: "number",
            description: "Maximum candidate ranges to return (default: 50, maximum: 200).",
          },
        },
        required: ["media_path", "timeline_start_seconds"],
      },
      handler: async (args: {
        media_path: string;
        timeline_start_seconds: number;
        source_in_seconds?: number;
        source_out_seconds?: number;
        noise_threshold_db?: number;
        min_duration_seconds?: number;
        max_candidates?: number;
      }) => {
        const timelineStart = args.timeline_start_seconds;
        const sourceIn = args.source_in_seconds ?? 0;
        const noiseDb = args.noise_threshold_db ?? -30;
        const minDuration = args.min_duration_seconds ?? 1.5;
        const maxCandidates = args.max_candidates ?? 50;

        if (!Number.isFinite(timelineStart) || timelineStart < 0) {
          return { success: false, error: "timeline_start_seconds must be a finite value greater than or equal to 0" };
        }
        if (!Number.isFinite(sourceIn) || sourceIn < 0) {
          return { success: false, error: "source_in_seconds must be a finite value greater than or equal to 0" };
        }
        if (args.source_out_seconds !== undefined && (
          !Number.isFinite(args.source_out_seconds) || args.source_out_seconds <= sourceIn
        )) {
          return { success: false, error: "source_out_seconds must be a finite value greater than source_in_seconds" };
        }
        if (!Number.isFinite(noiseDb) || noiseDb > 0) {
          return { success: false, error: `noise_threshold_db must be a finite dBFS value at or below 0 (got ${noiseDb}).` };
        }
        if (!Number.isFinite(minDuration) || minDuration <= 0) {
          return { success: false, error: `min_duration_seconds must be a finite value greater than 0 (got ${minDuration}).` };
        }
        if (!Number.isInteger(maxCandidates) || maxCandidates < 1 || maxCandidates > 200) {
          return { success: false, error: "max_candidates must be an integer from 1 through 200" };
        }

        const analysis = await analyzeSilenceFile(args.media_path, noiseDb, minDuration);
        if (!analysis.success) return analysis;

        const sourceOut = args.source_out_seconds ?? analysis.data.totalDurationSeconds;
        if (sourceOut === null) {
          return {
            success: false,
            error: "FFmpeg did not report the media duration. Provide source_out_seconds to define the visible source span before mapping silence candidates.",
          };
        }
        if (sourceOut <= sourceIn) {
          return { success: false, error: "The visible source span must have source_out_seconds greater than source_in_seconds" };
        }
        if (analysis.data.totalDurationSeconds !== null && sourceOut > analysis.data.totalDurationSeconds + 0.001) {
          return { success: false, error: "source_out_seconds cannot exceed the detected media duration" };
        }

        const mapping = mapSilenceIntervalsToTimeline(analysis.data.silenceIntervals, {
          sourceInSeconds: sourceIn,
          sourceOutSeconds: sourceOut,
          timelineStartSeconds: timelineStart,
          maxCandidates,
        });

        return {
          success: true,
          data: {
            planType: "silence-review-markers",
            sourceFileName: basename(args.media_path),
            sourcePlacement: {
              sourceInSeconds: Number(sourceIn.toFixed(3)),
              sourceOutSeconds: Number(sourceOut.toFixed(3)),
              timelineStartSeconds: Number(timelineStart.toFixed(3)),
              playbackRate: 1,
            },
            noiseThresholdDb: noiseDb,
            minDurationSeconds: minDuration,
            totalDetectedSilences: analysis.data.silenceIntervals.length,
            totalCandidateCount: mapping.totalCandidateCount,
            candidates: mapping.candidates,
            candidatesTruncated: mapping.truncated,
            markerMutationSupported: false,
            nextStep: "Review the mapped ranges, then explicitly add or omit markers in Premiere. This plan never creates markers or removes silence.",
            verificationScope: "Local decoded-source audio analysis plus arithmetic mapping for one known 1x placement only. It does not inspect Premiere clip timing, speed/remapping, multicam, nested sequences, rendered audio, or make any Premiere change.",
          },
        };
      },
    },

    detect_beats: {
      description:
        "Estimate a steady beat grid from a local audio or video file without changing Premiere. FFmpeg decodes at most 30 minutes to a bounded mono analysis stream; local onset autocorrelation returns BPM, phase-aligned beat times, confidence, and half/double-time alternatives.",
      parameters: {
        type: "object" as const,
        additionalProperties: false,
        properties: {
          media_path: { type: "string", description: "Absolute path to an existing local audio or video file." },
          max_beats: { type: "integer", minimum: 1, maximum: 2000, description: "Maximum beat times returned (default: 500)." },
        },
        required: ["media_path"],
      },
      handler: async (args: { media_path: string; max_beats?: number }) => {
        const maxBeats = args.max_beats ?? 500;
        if (!args.media_path) {
          return { success: false, error: "media_path is required." };
        }
        if (!Number.isInteger(maxBeats) || maxBeats < 1 || maxBeats > 2000) {
          return { success: false, error: "max_beats must be an integer from 1 through 2000." };
        }
        const mediaPath = resolve(args.media_path);
        if (!existsSync(mediaPath) || !statSync(mediaPath).isFile()) {
          return { success: false, error: `Media file not found on disk: ${mediaPath}` };
        }
        let bytes: Buffer;
        try {
          const result = await execFileAsync("ffmpeg", [
            "-nostdin", "-hide_banner", "-loglevel", "error", "-i", mediaPath,
            "-t", "1800", "-vn", "-sn", "-dn", "-ac", "1", "-ar", "4000", "-f", "s16le", "pipe:1",
          ], { encoding: "buffer", timeout: FFMPEG_TIMEOUT_MS, maxBuffer: 128 * 1024 * 1024 }) as unknown as { stdout: Buffer };
          bytes = result.stdout;
        } catch (error) {
          const failure = error as { code?: string; killed?: boolean; stderr?: Buffer | string; message?: string };
          const detail = Buffer.isBuffer(failure.stderr) ? failure.stderr.toString("utf8") : (failure.stderr ?? failure.message ?? "");
          return { success: false, error: failure.code === "ENOENT"
            ? "ffmpeg was not found on PATH; install FFmpeg to analyze beats."
            : failure.killed
            ? `ffmpeg timed out after ${FFMPEG_TIMEOUT_MS / 1000}s during beat analysis.`
            : `ffmpeg could not decode media for beat analysis: ${String(detail).trim() || "unknown error"}` };
        }
        let measurement: BeatMeasurement;
        try {
          const samples = new Int16Array(bytes.length >> 1);
          for (let index = 0; index < samples.length; index++) samples[index] = bytes.readInt16LE(index * 2);
          measurement = analyzeBeatPcm(samples, 4000);
        } catch (error) {
          // Only the analysis' own "no beat" outcomes are a musical result; any
          // other exception is a real failure and is reported as one.
          if (error instanceof NoBeatError) {
            return { success: false, error: `No steady beat found: ${error.message}. The media decoded fine; it may be speech, a quiet or ambient bed, or free-tempo music.` };
          }
          return { success: false, error: `Beat analysis failed: ${error instanceof Error ? error.message : String(error)}` };
        }
        const truncated = measurement.beatTimesSeconds.length > maxBeats;
        return {
          success: true,
          data: {
            ...measurement,
            halfTimeBpm: Number((measurement.bpm / 2).toFixed(1)),
            doubleTimeBpm: Number((measurement.bpm * 2).toFixed(1)),
            reliable: measurement.confidence >= 0.35,
            beatTimesSeconds: measurement.beatTimesSeconds.slice(0, maxBeats),
            beatTimesTruncated: truncated,
            verificationScope: "Local decoded-media estimate only. Low confidence and half/double-time ambiguity require human musical review; no markers, cuts, or Premiere changes are made.",
          },
        };
      },
    },

    analyze_loudness: {
      description:
        "Measure integrated loudness (LUFS), loudness range (LU), and true peak (dBFS) from a local media file using FFmpeg's EBU R128 filter. Analysis only: it does not normalize audio or change Premiere.",
      parameters: {
        type: "object" as const,
        properties: {
          media_path: {
            type: "string",
            description: "Absolute path to a local audio or video file. Provide this or project_item_id.",
          },
          project_item_id: {
            type: "string",
            description: "Project item whose local media path should be resolved through Premiere. Provide this or media_path.",
          },
          target_lufs: {
            type: "number",
            description: "Optional delivery target in LUFS (for example -14 streaming, -16 podcast, or -23 broadcast)",
          },
          tolerance_lu: {
            type: "number",
            description: "Allowed absolute difference from target_lufs (default: 1 LU)",
          },
          max_true_peak_dbfs: {
            type: "number",
            description: "Optional maximum acceptable true peak in dBFS (commonly -1 or -2)",
          },
        },
      },
      handler: async (args: {
        media_path?: string;
        project_item_id?: string;
        target_lufs?: number;
        tolerance_lu?: number;
        max_true_peak_dbfs?: number;
      }) => {
        if (!args.media_path && !args.project_item_id) {
          return { success: false, error: "analyze_loudness requires media_path or project_item_id." };
        }
        const tolerance = args.tolerance_lu ?? 1;
        if (args.target_lufs !== undefined && (!Number.isFinite(args.target_lufs) || args.target_lufs > 0 || args.target_lufs < -100)) {
          return { success: false, error: "target_lufs must be a finite value from -100 through 0" };
        }
        if (!Number.isFinite(tolerance) || tolerance < 0 || tolerance > 20) {
          return { success: false, error: "tolerance_lu must be a finite value from 0 through 20" };
        }
        if (args.max_true_peak_dbfs !== undefined && (!Number.isFinite(args.max_true_peak_dbfs) || args.max_true_peak_dbfs > 0 || args.max_true_peak_dbfs < -100)) {
          return { success: false, error: "max_true_peak_dbfs must be a finite value from -100 through 0" };
        }

        let mediaPath = args.media_path;
        let itemName: string | undefined;
        if (!mediaPath) {
          const escaped = escapeForExtendScript(args.project_item_id as string);
          const lookup = await sendCommand(buildToolScript(`
            var item = __findProjectItem("${escaped}");
            if (!item) return __error("Project item not found: ${escaped}");
            var path = "";
            try { path = item.getMediaPath(); } catch(e) {}
            if (!path) return __error("Project item has no local media path");
            return __result({ mediaPath: path, name: item.name });
          `), bridgeOptions);
          if (!lookup.success) return lookup;
          const data = lookup.data as { mediaPath: string; name?: string };
          mediaPath = data.mediaPath;
          itemName = data.name;
        }
        if (!existsSync(mediaPath)) {
          return { success: false, error: `Media file not found on disk: ${mediaPath}` };
        }

        try {
          await execFileAsync("ffmpeg", ["-version"], { timeout: 10_000 });
        } catch {
          return {
            success: false,
            error: "ffmpeg was not found on PATH. analyze_loudness requires FFmpeg because Premiere scripting exposes no EBU R128 measurements.",
          };
        }

        let stderr: string;
        try {
          const result = await execFileAsync("ffmpeg", [
            "-nostdin", "-hide_banner", "-i", mediaPath,
            "-vn", "-sn", "-dn", "-af", "ebur128=peak=true", "-f", "null", "-",
          ], { timeout: FFMPEG_TIMEOUT_MS, maxBuffer: 32 * 1024 * 1024 });
          stderr = result.stderr;
        } catch (error) {
          const failure = error as { killed?: boolean; stderr?: string; message?: string };
          if (failure.killed) {
            return { success: false, error: `ffmpeg timed out after ${FFMPEG_TIMEOUT_MS / 1000}s measuring ${mediaPath}.` };
          }
          const detail = (failure.stderr ?? failure.message ?? "").split(/\r?\n/).filter(Boolean).slice(-3).join(" ");
          return { success: false, error: `ffmpeg could not measure loudness for ${mediaPath}: ${detail || "unknown error"}` };
        }

        const measurement = parseEbur128Summary(stderr);
        if (measurement.integratedLufs === null) {
          return {
            success: false,
            error: "FFmpeg completed but did not return measurable integrated loudness. The file may contain no audio or digital silence.",
          };
        }
        const deltaLu = args.target_lufs === undefined
          ? null
          : Number((measurement.integratedLufs - args.target_lufs).toFixed(1));
        const loudnessPass = deltaLu === null ? null : Math.abs(deltaLu) <= tolerance;
        const truePeakPass = args.max_true_peak_dbfs === undefined || measurement.truePeakDbfs === null
          ? null
          : measurement.truePeakDbfs <= args.max_true_peak_dbfs;

        return {
          success: true,
          data: {
            mediaPath,
            projectItemName: itemName,
            ...measurement,
            target: args.target_lufs === undefined ? null : {
              lufs: args.target_lufs,
              toleranceLu: tolerance,
              deltaLu,
              loudnessPass,
              maxTruePeakDbfs: args.max_true_peak_dbfs ?? null,
              truePeakPass,
              passes: loudnessPass && (truePeakPass !== false),
            },
            verificationScope: "Local decoded-media measurement only. This does not normalize audio or prove a Premiere sequence mix or final export unless that exact exported file was measured.",
          },
        };
      },
    },

    normalize_loudness_file: {
      description:
        "Create a new loudness-normalized media derivative with FFmpeg, then remeasure that exact output using EBU R128. Never overwrites the input or an existing output file.",
      parameters: {
        type: "object" as const,
        properties: {
          input_path: { type: "string", description: "Existing local audio or video file" },
          output_path: { type: "string", description: "New output path; must not already exist" },
          target_lufs: { type: "number", description: "Integrated loudness target from -70 through -5 LUFS (default: -16)" },
          max_true_peak_dbfs: { type: "number", description: "True-peak ceiling from -9 through 0 dBFS (default: -1.5)" },
          tolerance_lu: { type: "number", description: "Post-render integrated-loudness tolerance (default: 1 LU)" },
        },
        required: ["input_path", "output_path"],
      },
      handler: async (args: { input_path: string; output_path: string; target_lufs?: number; max_true_peak_dbfs?: number; tolerance_lu?: number }) => {
        const inputPath = resolve(args.input_path);
        const outputPath = resolve(args.output_path);
        const target = args.target_lufs ?? -16;
        const truePeak = args.max_true_peak_dbfs ?? -1.5;
        const tolerance = args.tolerance_lu ?? 1;
        if (!Number.isFinite(target) || target < -70 || target > -5) return { success: false, error: "target_lufs must be from -70 through -5" };
        if (!Number.isFinite(truePeak) || truePeak < -9 || truePeak > 0) return { success: false, error: "max_true_peak_dbfs must be from -9 through 0" };
        if (!Number.isFinite(tolerance) || tolerance < 0 || tolerance > 5) return { success: false, error: "tolerance_lu must be from 0 through 5" };
        if (inputPath === outputPath) return { success: false, error: "output_path must differ from input_path" };
        if (!existsSync(inputPath) || !statSync(inputPath).isFile()) return { success: false, error: `Input file not found: ${inputPath}` };
        if (existsSync(outputPath)) return { success: false, error: `Output already exists and will not be overwritten: ${outputPath}` };
        if (!existsSync(dirname(outputPath)) || !statSync(dirname(outputPath)).isDirectory()) return { success: false, error: `Output directory does not exist: ${dirname(outputPath)}` };

        // Two-pass loudnorm: measure, then apply linearly with the measured values.
        // Single-pass (dynamic) loudnorm undershot a dense, clipped music-video mix by
        // 1.6 LU and resampled its audio to 96 kHz at a lower bitrate (live check).
        const failureOf = (error: unknown) => {
          const failure = error as { code?: string; killed?: boolean; stderr?: string; message?: string };
          if (failure.code === "ENOENT") return { success: false, error: "ffmpeg was not found on PATH" };
          if (failure.killed) return { success: false, error: "ffmpeg loudness normalization timed out after 300 seconds" };
          return { success: false, error: `ffmpeg normalization failed: ${(failure.stderr ?? failure.message ?? "unknown error").split(/\r?\n/).filter(Boolean).slice(-3).join(" ")}` };
        };
        const source = await probeAudioStream(inputPath);
        if (!source) return { success: false, error: `No audio stream found in ${inputPath}` };
        let firstPass: LoudnormStats;
        try {
          const measured = await execFileAsync("ffmpeg", [
            "-nostdin", "-hide_banner", "-i", inputPath, "-vn", "-sn", "-dn",
            "-af", `loudnorm=I=${target}:TP=${truePeak}:LRA=11:print_format=json`, "-f", "null", "-",
          ], { timeout: FFMPEG_TIMEOUT_MS, maxBuffer: 32 * 1024 * 1024 });
          firstPass = parseLoudnormJson(measured.stderr);
        } catch (error) {
          return failureOf(error);
        }
        // A loudness-range target below the source's own range forces dynamic mode;
        // allow the source's range so the gain can stay linear.
        const lra = Math.min(50, Math.max(11, Math.ceil(Number(firstPass.input_lra)) + 1));
        const filter = [
          `loudnorm=I=${target}`, `TP=${truePeak}`, `LRA=${lra}`,
          `measured_I=${firstPass.input_i}`, `measured_TP=${firstPass.input_tp}`, `measured_LRA=${firstPass.input_lra}`,
          `measured_thresh=${firstPass.input_thresh}`, `offset=${firstPass.target_offset}`, "linear=true", "print_format=json",
        ].join(":");
        const extension = extname(outputPath).toLowerCase();
        const aacContainer = [".mp4", ".m4a", ".mov", ".m4v", ".aac"].includes(extension);
        const audioCodecArgs = aacContainer
          ? ["-c:a", "aac", "-b:a", `${Math.max(192, Math.round((source.bitRate ?? 192000) / 1000))}k`]
          : [];
        let secondPass: LoudnormStats;
        try {
          const applied = await execFileAsync("ffmpeg", [
            "-nostdin", "-hide_banner", "-n", "-i", inputPath,
            "-af", filter, "-ar", String(source.sampleRate ?? 48000), ...audioCodecArgs,
            "-c:v", "copy", outputPath,
          ], { timeout: FFMPEG_TIMEOUT_MS, maxBuffer: 32 * 1024 * 1024 });
          secondPass = parseLoudnormJson(applied.stderr);
        } catch (error) {
          return failureOf(error);
        }
        if (!existsSync(outputPath) || !statSync(outputPath).isFile() || statSync(outputPath).size < 1) {
          return { success: false, error: "ffmpeg reported completion but no non-empty output file exists" };
        }

        let measurement: LoudnessMeasurement;
        try {
          const measured = await execFileAsync("ffmpeg", [
            "-nostdin", "-hide_banner", "-i", outputPath,
            "-vn", "-sn", "-dn", "-af", "ebur128=peak=true", "-f", "null", "-",
          ], { timeout: FFMPEG_TIMEOUT_MS, maxBuffer: 32 * 1024 * 1024 });
          measurement = parseEbur128Summary(measured.stderr);
        } catch (error) {
          return { success: false, error: `Normalized output exists but EBU R128 verification failed: ${error instanceof Error ? error.message : String(error)}` };
        }
        if (measurement.integratedLufs === null) return { success: false, error: "Normalized output exists but integrated loudness was not measurable" };
        const deltaLu = Number((measurement.integratedLufs - target).toFixed(1));
        const loudnessPass = Math.abs(deltaLu) <= tolerance;
        const truePeakPass = measurement.truePeakDbfs !== null && measurement.truePeakDbfs <= truePeak;
        return {
          success: true,
          data: {
            inputPath, outputPath, outputSizeBytes: statSync(outputPath).size,
            target: { integratedLufs: target, maxTruePeakDbfs: truePeak, toleranceLu: tolerance },
            measured: measurement, deltaLu,
            input: { integratedLufs: Number(firstPass.input_i), truePeakDbfs: Number(firstPass.input_tp), loudnessRangeLu: Number(firstPass.input_lra) },
            normalizationType: secondPass.normalization_type ?? null,
            audio: { sampleRate: source.sampleRate ?? 48000, codec: aacContainer ? "aac" : "ffmpeg default for the container", bitrateKbps: aacContainer ? Math.max(192, Math.round((source.bitRate ?? 192000) / 1000)) : null },
            verified: loudnessPass && truePeakPass,
            loudnessPass, truePeakPass,
            verificationScope: "The new output file exists and was remeasured locally. This does not prove subjective mix quality, rights, or Premiere timeline state.",
          },
        };
      },
    },
  };
}
